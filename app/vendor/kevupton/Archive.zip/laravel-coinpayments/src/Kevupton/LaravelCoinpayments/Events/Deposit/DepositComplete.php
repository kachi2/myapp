<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Date: 24/03/2018
 * Time: 3:44 PM
 */

namespace Kevupton\LaravelCoinpayments\Events\Deposit;

class DepositComplete extends AbstractDepositEvent
{

}