<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Date: 25/03/2018
 * Time: 9:14 PM
 */

namespace Kevupton\LaravelCoinpayments\Events\Withdrawal;


class WithdrawalUpdated extends AbstractWithdrawalEvent
{

}