<?php

define('COINPAYMENTS_CONFIG', 'coinpayments');