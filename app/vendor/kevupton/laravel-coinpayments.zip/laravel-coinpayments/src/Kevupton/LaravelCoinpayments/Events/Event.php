<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Date: 26/03/2018
 * Time: 7:16 PM
 */
namespace Kevupton\LaravelCoinpayments\Events;

use Illuminate\Queue\SerializesModels;

class Event
{
    use SerializesModels;
}