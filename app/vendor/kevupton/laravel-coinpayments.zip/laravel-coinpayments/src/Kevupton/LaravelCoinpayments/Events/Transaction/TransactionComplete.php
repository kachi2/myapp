<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Date: 25/03/2018
 * Time: 9:50 PM
 */

namespace Kevupton\LaravelCoinpayments\Events\Transaction;


class TransactionComplete extends AbstractTransactionEvent
{

}